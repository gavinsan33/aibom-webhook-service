# Minimal, dependency-free in-cluster Kubernetes REST client.
#
# Uses only the Python stdlib so it can run inside arbitrary user application
# images (runtime_detector.py runs as sitecustomize.py in the workload's own
# container) as well as the pinned discovery image, without requiring the
# `kubernetes` pip package to be installed anywhere it's imported.

import json
import os
import ssl
import urllib.error
import urllib.request

_SA_DIR = "/var/run/secrets/kubernetes.io/serviceaccount"

# Mirrors aibomdata's constants in aibomdata.go — the two must stay in sync,
# since the Go watcher and resolve_data_configmap_name() below each
# independently compute the same deterministic name for the same trigger.
_MAX_JOB_NAME_LENGTH = 63
_POSTPROCESS_SUFFIX = "-aibom-postprocess"
_CONFIGMAP_SUFFIX = "-data"

# aibomdata.go's WorkloadIdentitySuffix -- unrelated to the ConfigMap itself,
# but its length is what the Go side's truncatedTriggerBase() budgets the
# truncation against (the narrowest of the three suffixes it needs to
# support), applied uniformly to the postprocess Job name, the ConfigMap
# name, and the workload-identity name alike, specifically so one trigger
# name always maps to the same truncated base across all three -- otherwise
# two trigger names sharing a prefix up to a shorter cutoff but differing
# beyond it could produce the same WorkloadIdentityName while getting
# different ConfigMapNames, letting one job's identity cleanup delete
# another job's ServiceAccount/Role/RoleBinding/Secret out from under it.
# _postprocess_job_name() below must budget against this same length, not
# _POSTPROCESS_SUFFIX's (shorter) own length, or it silently computes a
# different ConfigMap name than the Go watcher does -- exactly the bug this
# comment exists to prevent from recurring (a bare/ReplicaSet-owned pod's
# discovery init container wrote into one ConfigMap name while the watcher
# read from another, so it always saw empty discovery/dataset data with no
# error logged, since a not-found ConfigMap Get() is deliberately silent).
_WORKLOAD_IDENTITY_SUFFIX_LEN = len("-aibom-workload-identity")


def _api_server():
    host = os.environ["KUBERNETES_SERVICE_HOST"]
    port = os.environ["KUBERNETES_SERVICE_PORT"]
    return f"https://{host}:{port}"


def _token():
    with open(os.path.join(_SA_DIR, "token")) as f:
        return f.read().strip()


def _ssl_context():
    return ssl.create_default_context(cafile=os.path.join(_SA_DIR, "ca.crt"))


def _request(method, path, body=None, content_type="application/json"):
    url = _api_server() + path
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {_token()}")
    req.add_header("Content-Type", content_type)
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req, context=_ssl_context(), timeout=15) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else None


def patch_configmap(namespace, name, data_updates):
    """Merge `data_updates` into ConfigMap `name`'s `data`, creating the
    ConfigMap if it doesn't exist yet. Safe to call concurrently from
    multiple pods/containers targeting the same ConfigMap — each caller only
    touches its own keys, and a lost create race is retried as a patch.
    """
    path = f"/api/v1/namespaces/{namespace}/configmaps/{name}"
    patch_body = {"data": data_updates}
    try:
        return _request(
            "PATCH", path, body=patch_body, content_type="application/merge-patch+json"
        )
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
        create_body = {
            "apiVersion": "v1",
            "kind": "ConfigMap",
            "metadata": {"name": name, "namespace": namespace},
            "data": data_updates,
        }
        try:
            return _request("POST", f"/api/v1/namespaces/{namespace}/configmaps", body=create_body)
        except urllib.error.HTTPError as create_err:
            if create_err.code != 409:
                raise
            # Lost the create race against a sibling pod/container — it exists now.
            return _request(
                "PATCH", path, body=patch_body, content_type="application/merge-patch+json"
            )


def create_custom_object(namespace, group, version, plural, body):
    """POST a namespaced custom resource, e.g. an AIBOM (aibom.io/v1alpha1)."""
    path = f"/apis/{group}/{version}/namespaces/{namespace}/{plural}"
    return _request("POST", path, body=body)


def set_custom_object_owner(namespace, group, version, plural, name, owner):
    """Sets `owner` (an ownerReferences entry) on an existing namespaced custom
    resource so the garbage collector deletes it along with the owner.
    Replaces any existing ownerReferences list (merge-patch semantics for
    lists)."""
    path = f"/apis/{group}/{version}/namespaces/{namespace}/{plural}/{name}"
    return _request(
        "PATCH",
        path,
        body={"metadata": {"ownerReferences": [owner]}},
        content_type="application/merge-patch+json",
    )


def get_custom_object(namespace, group, version, plural, name):
    """GET a namespaced custom resource, e.g. a KServe InferenceService
    (serving.kserve.io/v1beta1). Returns None if it doesn't exist (or has
    already been deleted) rather than raising, since callers use this for
    best-effort enrichment, not anything that should fail the caller outright.
    """
    path = f"/apis/{group}/{version}/namespaces/{namespace}/{plural}/{name}"
    try:
        return _request("GET", path)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def get_cluster_object(group, version, plural, name):
    """GET a cluster-scoped resource, e.g. an OpenShift Image
    (image.openshift.io/v1, whose object name is the digest itself,
    "sha256:..."). Returns None on 404/403 rather than raising, since callers
    use this for best-effort enrichment (git-provenance detection from
    BuildConfig commit labels) that should degrade quietly if the image
    wasn't built in-cluster or the caller lacks RBAC for it.
    """
    path = f"/apis/{group}/{version}/{plural}/{name}"
    try:
        return _request("GET", path)
    except urllib.error.HTTPError as e:
        if e.code in (404, 403):
            return None
        raise


def _postprocess_job_name(trigger_name):
    # Budgeted against _WORKLOAD_IDENTITY_SUFFIX_LEN, not len(_POSTPROCESS_SUFFIX)
    # -- see that constant's comment for why.
    max_base = _MAX_JOB_NAME_LENGTH - _WORKLOAD_IDENTITY_SUFFIX_LEN
    trigger_name = trigger_name[:max_base].rstrip("-")
    return trigger_name + _POSTPROCESS_SUFFIX


def resolve_data_configmap_name():
    """Returns the data ConfigMap name discovery/dataset scripts should write
    into. Prefers the webhook-injected AIBOM_DATA_CONFIGMAP env var, which is
    reliable for Job/JobSet/PyTorchJob/RayJob-owned pods (their trigger name
    comes from ownerReferences, already set before admission).

    Falls back to deriving it from POD_NAME for bare/ReplicaSet-owned pods
    (e.g. KServe predictors): their own pod name isn't assigned yet when the
    mutating webhook runs (the API server hasn't resolved generateName to a
    real name at that point), so the webhook can't bake in a static value for
    them — see mutator.go's dataConfigMapEnvVar. POD_NAME, a downward API
    value resolved later by the kubelet, is reliable by the time this
    actually runs.
    """
    configmap_name = os.environ.get("AIBOM_DATA_CONFIGMAP", "")
    if configmap_name:
        return configmap_name
    pod_name = os.environ.get("POD_NAME", "")
    if not pod_name:
        return ""
    return _postprocess_job_name(pod_name) + _CONFIGMAP_SUFFIX
