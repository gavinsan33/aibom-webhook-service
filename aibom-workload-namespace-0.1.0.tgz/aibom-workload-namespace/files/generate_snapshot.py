# Taken from coldpress's discovery script in 'user_snapshot.yaml' and modified.

import hashlib
import hmac
import signal
import subprocess
import sys
import json
import os
import re
from datetime import datetime

try:
    import k8s_api
except ImportError:
    k8s_api = None

# Instrumentation must never take the workload down (fail open, #104): this
# is an init container, so a crash or a hang here keeps the user's pod from
# starting at all. Every stage that touches something the workload or its
# image controls (a missing binary, a FIFO on the model PVC, a stalled API
# call) therefore runs through _run_stage, which turns an exception or a
# timeout into a warning plus a None result so whatever was collected still
# gets written. The mutator's `|| echo ...` wrapper around this script covers
# the rest (python3 missing, an error before the first stage).
_STAGE_TIMEOUT_S = 60


class _StageTimeout(Exception):
    pass


def _run_stage(name, fn, timeout_s=None):
    """Run fn() under a SIGALRM deadline; on any exception (including the
    timeout) warn and return None. SIGALRM interrupts a blocking
    syscall such as open() on a FIFO, which nothing else in-process can."""
    timeout_s = timeout_s or _STAGE_TIMEOUT_S

    def _on_alarm(signum, frame):
        raise _StageTimeout(f"timed out after {timeout_s}s")
    previous = signal.signal(signal.SIGALRM, _on_alarm)
    signal.alarm(timeout_s)
    try:
        return fn()
    except Exception as exc:
        print(f"WARNING: {name} failed, continuing without it: {exc}", file=sys.stderr)
        return None
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous)


def run_cmd(command):
    try:
        out = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        return out.stdout.strip() if out.returncode == 0 else "Not available"
    except Exception as e:
        return "Not available"

print("Collecting static system information...")

snapshot = {
    "timestamp": datetime.now().isoformat(),
    "pod_metadata": {
        "name": os.environ.get("POD_NAME", "unknown"),
        "uid": os.environ.get("POD_UID", "unknown"),
        "namespace": os.environ.get("POD_NAMESPACE", "unknown"),
        "ip": os.environ.get("POD_IP", "unknown"),
        "node": os.environ.get("NODE_NAME", "unknown"),
        "start_time": datetime.now().isoformat()
    },
    "system": {
        "cpu_model": run_cmd("grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2 | xargs"),
        "cpu_count": run_cmd("grep -c ^processor /proc/cpuinfo"),
        "cpu_cores_per_socket": run_cmd("lscpu | grep 'Core(s) per socket' | awk '{print $NF}' 2>/dev/null || echo 'N/A'"),
        "cpu_threads_per_core": run_cmd("lscpu | grep 'Thread(s) per core' | awk '{print $NF}' 2>/dev/null || echo 'N/A'"),
        "cpu_architecture": run_cmd("uname -m"),
        "cpu_current_freq_mhz": run_cmd("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null | awk '{print $1/1000}' || echo 'N/A'"),
        "cpu_max_freq_mhz": run_cmd("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null | awk '{print $1/1000}' || echo 'N/A'"),
        "cpu_min_freq_mhz": run_cmd("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq 2>/dev/null | awk '{print $1/1000}' || echo 'N/A'"),
        "cache_l1d": run_cmd("lscpu | grep 'L1d cache' | head -1 | sed -E 's/^[^:]*: *//; s/ *\\(.*//' 2>/dev/null || echo 'N/A'"),
        "cache_l1i": run_cmd("lscpu | grep 'L1i cache' | head -1 | sed -E 's/^[^:]*: *//; s/ *\\(.*//' 2>/dev/null || echo 'N/A'"),
        "cache_l2": run_cmd("lscpu | grep 'L2 cache' | head -1 | sed -E 's/^[^:]*: *//; s/ *\\(.*//' 2>/dev/null || echo 'N/A'"),
        "cache_l3": run_cmd("lscpu | grep 'L3 cache' | head -1 | sed -E 's/^[^:]*: *//; s/ *\\(.*//' 2>/dev/null || echo 'N/A'"),
        "memory_total_gb": run_cmd("grep MemTotal /proc/meminfo | awk '{printf \"%.2f\", $2/1024/1024}'"),
        "memory_available_gb": run_cmd("grep MemAvailable /proc/meminfo | awk '{printf \"%.2f\", $2/1024/1024}'"),
        "memory_free_gb": run_cmd("grep MemFree /proc/meminfo | awk '{printf \"%.2f\", $2/1024/1024}'"),
        "numa_node_count": run_cmd("ls -d /sys/devices/system/node/node* 2>/dev/null | wc -l"),
        "kernel_version": run_cmd("uname -r"),
        "uptime_seconds": run_cmd("cat /proc/uptime | awk '{print $1}'")
    },
    "gpu": {
        "gpu_count": run_cmd("nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l"),
        "gpu_models": run_cmd("nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null"),
        "gpu_memory_per_device_mb": run_cmd("nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null"),
        "gpu_driver_version": run_cmd("nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1"),
        "cuda_version": run_cmd("nvidia-smi | grep 'CUDA Version' | awk '{print $9}' 2>/dev/null || echo 'N/A'")
    },
    "network": {
        "interface_names": run_cmd("ls /sys/class/net 2>/dev/null | grep -v lo | tr '\\n' ', ' | sed 's/,$//'"),
        "rdma_devices": run_cmd("ls /sys/class/infiniband 2>/dev/null | tr '\\n' ', ' | sed 's/,$//' || echo 'None'"),
        "rdma_device_count": run_cmd("ls /sys/class/infiniband 2>/dev/null | wc -l"),
        "primary_mtu": run_cmd("cat /sys/class/net/eth0/mtu 2>/dev/null || echo 'N/A'"),
        "tcp_rmem": run_cmd("cat /proc/sys/net/ipv4/tcp_rmem 2>/dev/null || echo 'N/A'"),
        "tcp_wmem": run_cmd("cat /proc/sys/net/ipv4/tcp_wmem 2>/dev/null || echo 'N/A'"),
        "tcp_congestion_control": run_cmd("cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || echo 'N/A'")
    },
    "storage": {
        "block_devices": run_cmd("lsblk -nd -o NAME,SIZE 2>/dev/null | grep -v loop"),
        "nvme_count": run_cmd("ls /dev/nvme* 2>/dev/null | grep -c nvme0n || echo '0'"),
        "tmpfs_size": run_cmd("df -h /tmp 2>/dev/null | tail -1 | awk '{print $2}'"),
        "tmpfs_avail": run_cmd("df -h /tmp 2>/dev/null | tail -1 | awk '{print $4}'"),
        "io_scheduler": run_cmd("cat /sys/block/sda/queue/scheduler 2>/dev/null | grep -o '\\[.*\\]' | tr -d '[]' || echo 'N/A'")
    },
    "performance_config": {
        "cpu_governor": run_cmd("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo 'N/A'"),
        "numa_balancing": run_cmd("cat /proc/sys/kernel/numa_balancing 2>/dev/null || echo 'N/A'"),
        "transparent_hugepages": run_cmd("cat /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null | grep -o '\\[.*\\]' | tr -d '[]' || echo 'N/A'"),
        "swappiness": run_cmd("cat /proc/sys/vm/swappiness 2>/dev/null || echo 'N/A'"),
        "dirty_ratio": run_cmd("cat /proc/sys/vm/dirty_ratio 2>/dev/null || echo 'N/A'"),
        "dirty_background_ratio": run_cmd("cat /proc/sys/vm/dirty_background_ratio 2>/dev/null || echo 'N/A'"),
        "max_map_count": run_cmd("cat /proc/sys/vm/max_map_count 2>/dev/null || echo 'N/A'"),
        "file_max": run_cmd("cat /proc/sys/fs/file-max 2>/dev/null || echo 'N/A'")
    },
    "process_limits": {
        "max_user_processes": run_cmd("ulimit -u 2>/dev/null || echo 'N/A'"),
        "max_open_files": run_cmd("ulimit -n 2>/dev/null || echo 'N/A'"),
        "max_stack_size_kb": run_cmd("ulimit -s 2>/dev/null || echo 'N/A'"),
        "max_memory_size_kb": run_cmd("ulimit -m 2>/dev/null || echo 'N/A'"),
        "cgroup_cpu_quota": run_cmd("cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us 2>/dev/null || echo 'N/A'"),
        "cgroup_cpu_period": run_cmd("cat /sys/fs/cgroup/cpu/cpu.cfs_period_us 2>/dev/null || echo 'N/A'"),
        "cgroup_memory_limit_bytes": run_cmd("cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || echo 'N/A'")
    }
}

def _write_local_snapshot():
    # Write JSON locally for debugging/parity with prior behavior
    with open("/tmp/result/discovery.json", "w") as f:
        json.dump(snapshot, f, indent=2)


_run_stage("local snapshot write", _write_local_snapshot)

def resolve_inference_service_storage(namespace):
    """Resolve model identity from the owning KServe InferenceService's
    declared storage.path/storageUri, for predictors backed by an S3/MinIO
    data-connection bucket (spec.predictor.model.storage.key/path) rather
    than a custom serving container — the predictor's built-in vLLM container
    always runs with a fixed --model=/mnt/models mount, so there's no CLI arg
    identifying the actual model.

    This runs here, in the discovery init container at pod startup, rather
    than later from the always-on watcher at pod deletion: deleting the
    InferenceService is the normal way one of these pods gets deleted at all,
    and Kubernetes' garbage collector removes the InferenceService from etcd
    immediately, well before the delete cascades down to this pod — resolving
    it lazily at deletion time would lose that race almost every time.
    """
    isvc_name = os.environ.get("INFERENCESERVICE_NAME", "")
    if not k8s_api or not namespace or not isvc_name:
        return None
    try:
        isvc = k8s_api.get_custom_object(namespace, "serving.kserve.io", "v1beta1", "inferenceservices", isvc_name)
    except Exception as e:
        print(f"WARNING: could not get InferenceService {namespace}/{isvc_name}: {e}")
        return None
    if not isvc:
        return None

    model = ((isvc.get("spec") or {}).get("predictor") or {}).get("model") or {}
    storage = model.get("storage") or {}
    path = storage.get("path")
    storage_key = storage.get("key")
    storage_uri = model.get("storageUri")

    if not path and not storage_uri:
        return None

    result = {"inference_service": isvc_name}
    if path:
        result["storage_path"] = path
    if storage_key:
        result["storage_key"] = storage_key
    if storage_uri:
        result["storage_uri"] = storage_uri
    return result


_MODEL_FILE_MAX_BYTES = 5 * 1024 * 1024
_HEX40 = re.compile(r"^[0-9a-f]{40}$")


def _read_small_file(path, limit=_MODEL_FILE_MAX_BYTES):
    # Regular files only: the model PVC is workload-controlled, and open() on
    # a FIFO blocks until a writer appears, hanging the init container (#104).
    # isfile() follows symlinks, so a link to a FIFO or device is skipped too.
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "rb") as f:
            return f.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return None


def read_model_source_files(model_dir):
    """Read identity/config metadata out of a pre-pulled model directory
    (a KServe pvc:// storageUri mounted read-only at model_dir -- see
    mutator.go's modelSourcePVC). Only small metadata files are read, never
    weights. Everything here is best-effort identification from files anyone
    with write access to the PVC could have edited, not verification.

    Returns a dict with whichever of these could be resolved, or None:
      repo_id        Hugging Face "org/name", only when the README's
                     license_link repo name agrees with its H1 title (a
                     fine-tune's license_link often points at its base model)
      base_model     README front matter base_model, if a plain string
      revision       commit the snapshot was downloaded at, from
                     huggingface_hub's .cache/huggingface/download metadata
      architectures, model_type, dtype, max_position_embeddings
                     from config.json
      total_size_bytes  from model.safetensors.index.json
    """
    if not model_dir or not os.path.isdir(model_dir):
        return None
    out = {}

    readme = _read_small_file(os.path.join(model_dir, "README.md"), 64 * 1024)
    if readme:
        front = re.match(r"^---\s*\n(.*?)\n---\s*(?:\n|$)", readme, re.S)
        front_text = front.group(1) if front else ""
        body = readme[front.end():] if front else readme
        base = re.search(r"^base_model:[ \t]*([^\s\[#][^\n#]*?)[ \t]*$", front_text, re.M)
        if base:
            out["base_model"] = base.group(1).strip("'\"")
        link = re.search(r"^license_link:\s*\S*huggingface\.co/([\w.-]+)/([\w.-]+)/", front_text, re.M)
        title = re.search(r"^#\s+(.+?)\s*$", body, re.M)
        if link and title and link.group(2).lower() == title.group(1).strip().lower():
            out["repo_id"] = f"{link.group(1)}/{link.group(2)}"

    meta_dir = os.path.join(model_dir, ".cache", "huggingface", "download")
    try:
        for fname in sorted(os.listdir(meta_dir)):
            if not fname.endswith(".metadata"):
                continue
            text = _read_small_file(os.path.join(meta_dir, fname), 1024)
            first = (text or "").split("\n", 1)[0].strip()
            if _HEX40.match(first):
                out["revision"] = first
                break
    except OSError:
        pass

    config_text = _read_small_file(os.path.join(model_dir, "config.json"))
    if config_text:
        try:
            config = json.loads(config_text)
        except ValueError:
            config = None
        if isinstance(config, dict):
            for src, dst in (
                ("architectures", "architectures"),
                ("model_type", "model_type"),
                ("max_position_embeddings", "max_position_embeddings"),
            ):
                if config.get(src) is not None:
                    out[dst] = config[src]
            dtype = config.get("torch_dtype") or config.get("dtype")
            if isinstance(dtype, str):
                out["dtype"] = dtype

    index_text = _read_small_file(os.path.join(model_dir, "model.safetensors.index.json"))
    if index_text:
        try:
            total = (json.loads(index_text).get("metadata") or {}).get("total_size")
        except (ValueError, AttributeError):
            total = None
        if isinstance(total, int):
            out["total_size_bytes"] = total

    return out or None


_SIGNING_KEY_PATH = "/var/run/secrets/aibom/discovery-signing/hmac-key"


def sign_payload(payload):
    """HMAC-SHA256 payload's canonical bytes with the per-namespace signing
    key, so the watcher can later verify that a discovery-<pod>.json or
    storage-<pod>.json entry genuinely came from this (platform-controlled)
    discovery container rather than being fabricated or overwritten by the
    workload's own application container, which is never given this key.
    Both keys are safe to sign with the same key: both are written by this
    same trusted process. dataset-<pod>.json is signed separately, by the
    aibom-dataset-sidecar container with its own key (see #47) -- never by
    the workload's runtime_detector.py hook itself, since a key handed to
    that untrusted process wouldn't prove anything about data that same
    process produced.

    Returns None (unsigned) if the key isn't mounted -- e.g. a namespace
    whose aibom-workload-namespace chart install predates signing.yaml --
    so a missing key degrades to "unverifiable" rather than failing pod
    startup. The watcher treats an unsigned payload as untrusted once a
    per-namespace key does exist, but passes it through unverified if the
    whole namespace has no key configured yet.
    """
    try:
        with open(_SIGNING_KEY_PATH, "rb") as f:
            key = f.read().strip()
    except OSError:
        return None
    if not key:
        return None
    return hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()


# Write directly into the AIBOM data ConfigMap the webhook told us about,
# rather than printing to stdout for the watcher to scrape from pod logs.
pod_name = os.environ.get("POD_NAME", "")
pod_namespace = os.environ.get("POD_NAMESPACE", "")
configmap_name = _run_stage(
    "ConfigMap name lookup",
    lambda: k8s_api.resolve_data_configmap_name() if k8s_api else "",
)

# Canonical (sorted-key, no incidental whitespace) serialization: this exact
# string is what gets signed and later re-hashed by the watcher, so it must
# be reproduced byte-for-byte, not just semantically equivalent JSON.
discovery_payload = json.dumps(snapshot, sort_keys=True, separators=(",", ":"))
data_updates = {f"discovery-{pod_name}.json": discovery_payload}
signature = sign_payload(discovery_payload)
if signature:
    data_updates[f"discovery-{pod_name}.sig"] = signature

storage_info = _run_stage(
    "InferenceService storage lookup", lambda: resolve_inference_service_storage(pod_namespace))
model_files = _run_stage(
    "model source file read", lambda: read_model_source_files(os.environ.get("AIBOM_MODEL_DIR", "")))
if model_files:
    storage_info = dict(storage_info or {})
    storage_info["model_files"] = model_files
if storage_info:
    # Same canonical serialization requirement as discovery_payload above:
    # signed and later re-hashed byte-for-byte by the watcher.
    storage_payload = json.dumps(storage_info, sort_keys=True, separators=(",", ":"))
    data_updates[f"storage-{pod_name}.json"] = storage_payload
    storage_signature = sign_payload(storage_payload)
    if storage_signature:
        data_updates[f"storage-{pod_name}.sig"] = storage_signature

if k8s_api and pod_name and pod_namespace and configmap_name:
    _run_stage(
        f"write to ConfigMap {configmap_name}",
        lambda: k8s_api.patch_configmap(pod_namespace, configmap_name, data_updates),
    )
else:
    print("WARNING: k8s_api unavailable or POD_NAME/POD_NAMESPACE/AIBOM_DATA_CONFIGMAP not set, skipping ConfigMap write")

print("Snapshot generation complete!")
